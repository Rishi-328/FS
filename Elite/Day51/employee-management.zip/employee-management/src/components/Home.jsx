import React from 'react'

export default function Home() {
  return (
    <div className="d-flex justify-content-center align-items-center vh-100">
      <h1>Welcome to the Employee Management System</h1>
    </div>
  )
}
